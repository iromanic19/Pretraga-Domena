﻿using System;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Whois;
using System.Net;
using Xamarin.Essentials;

namespace PretragaDomena
{
    public static class GlobalVariables
    {
        public static string password = "pretragadomena1!";
        public static string saEmaila = "pretragadomena@gmail.com";

    }
}