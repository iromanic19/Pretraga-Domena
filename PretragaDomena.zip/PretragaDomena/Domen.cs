﻿using PretragaDomena.Models;
using PretragaDomena.ViewModels;
using PretragaDomena.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.IO;
using System.Globalization;
using Plugin.LocalNotifications;
namespace PretragaDomena
{
    public class Domen
    {
        public string domen { get; set; }
        public DateTime expirationDate { get; set; }
        public bool favorite { get; set; }
        public bool notifikacija { get; set; }
        public Image image { get; set; }
        public Image notifikacijaImage { get; set; }
        public Domen(string unos, bool omiljen)
        {
            domen = unos;
            favorite = omiljen;
            notifikacija = false;

            image = new Image();
            notifikacijaImage = new Image();
            if (!omiljen)
                image.Source = ImageSource.FromFile("notFavoriteStar.png");
            else
                image.Source = ImageSource.FromFile("favoriteStar.png");
            notifikacijaImage.Source = ImageSource.FromFile("notificationDisabled.png");
        }
        public Domen(string unos, bool omiljen, bool ukljuceneNotifikacije, string dt)
        {
            domen = unos;
            favorite = omiljen;
            notifikacija = ukljuceneNotifikacije;
            expirationDate = DateTime.ParseExact(dt, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            image = new Image();
            notifikacijaImage = new Image();
            if (!omiljen)
                image.Source = ImageSource.FromFile("notFavoriteStar.png");
            else
                image.Source = ImageSource.FromFile("favoriteStar.png");
            if(!notifikacija)
                notifikacijaImage.Source = ImageSource.FromFile("notificationDisabled.png");
            else
                notifikacijaImage.Source = ImageSource.FromFile("notificationEnabled.png");
        }
        public void swapImage()
        {
            favorite = !favorite;
            if(favorite)
            {
                image.Source = ImageSource.FromFile("favoriteStar.png");
            }
            else
            {
                image.Source = ImageSource.FromFile("notFavoriteStar.png");
            }
        }
        public void swapNotificationImage()
        {
            string datum = expirationDate.ToString("yyyy-MM-dd");
            int id = (datum[0] - 48) * 10000000 + (datum[1] - 48) * 1000000 + (datum[2] - 48) * 100000 +
                (datum[3] - 48) * 10000 + (datum[5] - 48) * 1000 + (datum[6] - 48) * 100 +
                (datum[8] - 48) * 10 + (datum[9] - 48);
            Console.WriteLine(id);
            notifikacija = !notifikacija;
            if (notifikacija)
            {
                if(NewItemPage.push)
                    CrossLocalNotifications.Current.Show(domen, $"{domen} ističe za 2 dana.", id, expirationDate.AddDays(-2));
                else
                {

                }
                notifikacijaImage.Source = ImageSource.FromFile("notificationEnabled.png");
            } 
            else
            {
                if(NewItemPage.push)
                    CrossLocalNotifications.Current.Cancel(id);
                else
                {

                }
                notifikacijaImage.Source = ImageSource.FromFile("notificationDisabled.png");
            }
        }
        public override string ToString()
        {
            return domen;
        }
    }
}
