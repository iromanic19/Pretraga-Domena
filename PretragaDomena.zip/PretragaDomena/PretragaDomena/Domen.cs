﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PretragaDomena
{
    public class Domen
    {
        public string domen { get; set; }
        public Domen(string unos)
        {
            domen = unos;
        }
        public override string ToString()
        {
            return domen;
        }
    }
}
