﻿using PretragaDomena.Models;
using PretragaDomena.ViewModels;
using PretragaDomena.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using PCLStorage;
using System.Threading.Tasks;

namespace PretragaDomena.Views
{
    public partial class ItemsPage : ContentPage
    {
        ItemsViewModel _viewModel;

        public IList<Domen> IstorijaDomeni { get; private set; }

        public ItemsPage()
        {
            InitializeComponent();
            IstorijaDomeni = new List<Domen>();
            BindingContext = this;
        }

        protected override void OnAppearing()
        {
            
        }
    }
}