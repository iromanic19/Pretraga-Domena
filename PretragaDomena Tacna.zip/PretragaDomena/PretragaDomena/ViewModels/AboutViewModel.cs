﻿using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using System.ComponentModel;
using Xamarin.Forms.Xaml;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PretragaDomena.ViewModels
{
    public class AboutViewModel : BaseViewModel
    {
        //public IList<Domen> Domeni { get; set; } = new List<Domen>();
        //public int brojac = 0;
        //public ICommand AddItemCommand { get; set; }
        public AboutViewModel()
        {
            Title = "About";
            OpenWebCommand = new Command(async () => await Browser.OpenAsync("https://aka.ms/xamarin-quickstart"));
        }
        public ICommand OpenWebCommand { get; }
        //public void dodajDomene()
        //{
        //    brojac++;
        //    Domeni.Add(new Domen(PretragaDomena.Text));
        //}
    }
}