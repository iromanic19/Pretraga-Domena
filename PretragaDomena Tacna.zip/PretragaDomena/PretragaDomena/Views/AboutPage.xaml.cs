﻿using System;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PCLStorage;
using System.Threading.Tasks;
using System.IO;
using System.Net.Sockets;

namespace PretragaDomena.Views
{

    public partial class AboutPage : ContentPage
    {
        public IList<Domen> Domeni { get; private set; }
        public static string ImeFajla = "IstorijaDomena";
        TcpClient tcpWhois;
        NetworkStream nsWhois;
        BufferedStream bfWhois;
        StreamWriter strmSend;
        StreamReader strmRecive;

        public AboutPage()
        {
            InitializeComponent();
            Domeni = new List<Domen>();
        }
        public void Submit(object sender, EventArgs args)
        {
            //((Button)sender).Text = PretragaDomena.Text;
            //Lista.ItemsSource = Domeni;
            if (PretragaDomena.Text != "")
            {
                Domen nov = new Domen(PretragaDomena.Text);
                Domeni.Add(nov);
                BindingContext = null;
                BindingContext = this;
                var filename = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), ImeFajla);
                System.IO.File.WriteAllText(filename, PretragaDomena.Text);
                DisplayAlert("Alert", "You have been alerted", "OK");
            }
        }

        public async Task<bool> IsFileExistAsync(string fileName, IFolder rootFolder = null)
        {
            IFolder folder = rootFolder ?? FileSystem.Current.LocalStorage;
            ExistenceCheckResult folderexist = await folder.CheckExistsAsync(fileName);
            if (folderexist == ExistenceCheckResult.FileExists)
            {
                return true;

            }
            return false;
        }
    }
}