﻿using PretragaDomena.Models;
using PretragaDomena.ViewModels;
using PretragaDomena.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.IO;
using Whois;
using System.Net;
using System.Timers;
using System.Net.Mail;
namespace PretragaDomena.Views
{
    public partial class ItemsPage : ContentPage
    {
        SmtpClient SmtpServer;
        private void sendMail(string subjectText, string bodyText) //object sender, EventArgs e, 
        {
            try
            {
                SmtpServer = new SmtpClient("smtp.gmail.com");
                SmtpServer.Port = 587;
                SmtpServer.Host = "smtp.gmail.com";
                SmtpServer.EnableSsl = true;
                SmtpServer.UseDefaultCredentials = false;
                SmtpServer.Credentials = new System.Net.NetworkCredential("pretragadomena@gmail.com", GlobalVariables.password); //"pretragadomena1!"
                SmtpServer.SendAsync(GlobalVariables.saEmaila, NewItemPage.eMail, subjectText, bodyText, "xyz123d");
                SmtpServer.SendCompleted += slanjeEmailaUspesno;
            }
            catch (Exception err)
            {
            }
        }
        private void slanjeEmailaUspesno(object sender, EventArgs e)
        {
        }
        //Mail
        public void provera(Object source, ElapsedEventArgs e)
        {
            if (NewItemPage.push)
                return;
            for (int i = 0; i < IstorijaDomeni.Count; i++)
            {
                if (IstorijaDomeni[i].notifikacija)
                {
                    sendMail(IstorijaDomeni[i].domen, $"{IstorijaDomeni[i].domen} ističe za 2 dana."); //sendMail(string emailText, string subjectText, string bodyText)
                }
            }

        }
        ItemsViewModel _viewModel;

        public IList<Domen> IstorijaDomeni { get; private set; }

        public ItemsPage()
        {
            InitializeComponent();
            IstorijaDomeni = new List<Domen>();
        }

        public void OnLabelTapped(object sender, EventArgs args)
        {
            for (int i = 0; i < IstorijaDomeni.Count; i++)
            {
                if (IstorijaDomeni[i].domen == ((StackLayout)sender).BindingContext.ToString())
                {
                    var whois = new WhoisLookup();
                    var response = whois.Lookup(((StackLayout)sender).BindingContext.ToString());
                    var address = Dns.GetHostAddresses(((StackLayout)sender).BindingContext.ToString());
                    string[] ips = address.Select(ip => ip.ToString()).ToArray();

                    string s = response.Content;
                    int start = s.IndexOf("Domain") + 1;
                    int end = s.IndexOf("Registrar: MarkMonitor, Inc.", start);
                    string result = s.Substring(start, end - start);
                    ////Console.WriteLine(response.Content);
                    DisplayAlert(((StackLayout)sender).BindingContext.ToString(), "WHOIS: " + "\r\n" + "IPAddress: " + ips[0] + "\r\n" + result, "OK");
                    break;
                }
            }
        }

        protected override void OnAppearing()
        {
            System.Timers.Timer aTimer = new System.Timers.Timer();
            aTimer.Elapsed += new ElapsedEventHandler(provera);
            aTimer.Interval = 5000;
            aTimer.Enabled = true;
            IstorijaDomeni.Clear();
            //string[] niz = PCLFile.ReadAllTextAsync(AboutPage.ImeFajla).Result.Split(';');
            if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla)))
            {
                string[] niz = File.ReadAllText((Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla))).Split(';');
                Console.WriteLine(File.ReadAllText((Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla))));
                for (int i = 1; i < niz.Length; i+=4)
                {
                    Domen temp = new Domen(niz[i], Convert.ToBoolean(niz[i+1]), Convert.ToBoolean(niz[i+2]), niz[i+3]);
                    IstorijaDomeni.Add(temp);
                }
                //IstorijaDomeni.Add(niz.Split(';'));
                BindingContext = null;
                BindingContext = this;
            }
        }
        public void favoriteSwap(object sender, EventArgs args)
        {
            Console.WriteLine(((ImageButton)sender).BindingContext);
            for(int i = 0; i < IstorijaDomeni.Count;i++)
            {
                if(IstorijaDomeni[i] == ((ImageButton)sender).BindingContext)
                {
                    IstorijaDomeni[i].swapImage();
                }
            }
            string cuvanje = $";{IstorijaDomeni[0].domen};{Convert.ToString(IstorijaDomeni[0].favorite)};" +
                $"{Convert.ToString(IstorijaDomeni[0].notifikacija)};{IstorijaDomeni[0].expirationDate.ToString("yyyy-MM-dd")}";
            for(int i = 1; i < IstorijaDomeni.Count;i++)
            {
                cuvanje = cuvanje + ";" + IstorijaDomeni[i].domen + ";" + Convert.ToString(IstorijaDomeni[i].favorite) +
                    ";" + Convert.ToString(IstorijaDomeni[i].notifikacija) + ";" +
                    IstorijaDomeni[i].expirationDate.ToString("yyyy-MM-dd");
            }
            Console.WriteLine(cuvanje);
            File.WriteAllText(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla), cuvanje);
        }
        public void notificationSwap(object sender, EventArgs args)
        {
            Console.WriteLine(((ImageButton)sender).BindingContext);
            for (int i = 0; i < IstorijaDomeni.Count; i++)
            {
                if (IstorijaDomeni[i] == ((ImageButton)sender).BindingContext)
                {
                    IstorijaDomeni[i].swapNotificationImage();
                }
            }
            string cuvanje = $";{IstorijaDomeni[0].domen};{Convert.ToString(IstorijaDomeni[0].favorite)};" +
                $"{Convert.ToString(IstorijaDomeni[0].notifikacija)};{IstorijaDomeni[0].expirationDate.ToString("yyyy-MM-dd")}";
            for (int i = 1; i < IstorijaDomeni.Count; i++)
            {
                cuvanje = cuvanje + ";" + IstorijaDomeni[i].domen + ";" + Convert.ToString(IstorijaDomeni[i].favorite) +
                    ";" + Convert.ToString(IstorijaDomeni[i].notifikacija) + ";" + 
                    Convert.ToString(IstorijaDomeni[i].expirationDate.ToString("yyyy-MM-dd"));
            }
            Console.WriteLine(cuvanje);
            File.WriteAllText(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla), cuvanje);
        }
    }
}