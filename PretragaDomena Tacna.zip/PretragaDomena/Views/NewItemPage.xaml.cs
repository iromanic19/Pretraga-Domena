﻿using PretragaDomena.Models;
using PretragaDomena.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Timers;
using System.Net;
using System.Net.Mail;
using System.IO;
using Whois;

namespace PretragaDomena.Views
{
    public partial class NewItemPage : ContentPage
    {
        public IList<Domen> Domeni;
        SmtpClient SmtpServer;
        private void sendMail(string subjectText, string bodyText) //object sender, EventArgs e, 
        {
            try
            {
                SmtpServer = new SmtpClient("smtp.gmail.com");
                SmtpServer.Port = 587;
                SmtpServer.Host = "smtp.gmail.com";
                SmtpServer.EnableSsl = true;
                SmtpServer.UseDefaultCredentials = false;
                SmtpServer.Credentials = new System.Net.NetworkCredential("pretragadomena@gmail.com", GlobalVariables.password); //"pretragadomena1!"
                SmtpServer.SendAsync(GlobalVariables.saEmaila, NewItemPage.eMail, subjectText, bodyText, "xyz123d");
                SmtpServer.SendCompleted += slanjeEmailaUspesno;
            }
            catch (Exception err)
            {
                DisplayAlert("Failed", err.Message, "OK!");
            }
        }
        private void slanjeEmailaUspesno(object sender, EventArgs e)
        {
            DisplayAlert("Uspeh", "Mail poslat uspesno", "OK");
        }
        //Mail
        public void provera(Object source, ElapsedEventArgs e)
        {
            if (NewItemPage.push)
                return;
            for (int i = 0; i < Domeni.Count; i++)
            {
                if (Domeni[i].notifikacija)
                {
                    sendMail(Domeni[i].domen, $"{Domeni[i].domen} ističe za 2 dana."); //sendMail(string emailText, string subjectText, string bodyText)
                }
            }

        }
        public Item Item { get; set; }
        public static string eMail;
        public static bool push = false;
        public void MailPromena(object sender, EventArgs args)
        {
            eMail = Mail.Text;
            //DisplayAlert(eMail, eMail, eMail);
        }
        public void CheckPromena(object sender, EventArgs args)
        {
            push = ((RadioButton)sender).IsChecked;
            //if(push)
            //    DisplayAlert("t","t","t");
            //else
            //    DisplayAlert("f", "f", "f");
        }
        public NewItemPage()
        {
            Domeni = new List<Domen>();
            InitializeComponent();
            
            BindingContext = new NewItemViewModel();
        }
        protected override void OnAppearing()
        {
            Domeni.Clear();
            if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla)))
            {
                string[] niz = File.ReadAllText((Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AboutPage.ImeFajla))).Split(';');
                for (int i = 1; i < niz.Length; i += 4)
                {
                    if (Convert.ToBoolean(niz[i + 1]))
                    {
                        Console.WriteLine(niz[i] + ", " + niz[i + 1] + ", " + niz[i + 2] + ", " + niz[i + 3]);
                        Domen temp = new Domen(niz[i], Convert.ToBoolean(niz[i + 1]), Convert.ToBoolean(niz[i + 2]), niz[i + 3]);
                        Domeni.Add(temp);
                    }
                }
            }
            System.Timers.Timer aTimer = new System.Timers.Timer();
            aTimer.Elapsed += new ElapsedEventHandler(provera);
            aTimer.Interval = 3600000;
            aTimer.Enabled = true;
        }
    }
}